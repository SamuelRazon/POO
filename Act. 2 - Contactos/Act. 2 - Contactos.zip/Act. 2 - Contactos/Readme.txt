EJECUCIÓN:
x. Instala java
0. Abre las carpetas "out/pruduction/Act. 2 - Contactos"
1. Haz clic derecho en la carpeta que contiene los archivos y selecciona "Abrir en terminal".
2. Ingresa el siguiente comando: `java Main`.
